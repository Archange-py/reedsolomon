# TODO file

- Uses Sympy to get factorised and canonic form ?

- Make a proper documentation, with examples for the Polynomial class.