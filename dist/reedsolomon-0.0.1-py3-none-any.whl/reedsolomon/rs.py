

class RS:
    pass