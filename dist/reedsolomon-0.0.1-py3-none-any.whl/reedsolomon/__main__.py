"""A file to configure calling in the prompt line"""

import sys


def main():
    print("Not implemented for the moment.")


if __name__ == '__main__':
    sys.exit(main())